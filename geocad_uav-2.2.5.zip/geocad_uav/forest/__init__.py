"""Forest planting designer."""
